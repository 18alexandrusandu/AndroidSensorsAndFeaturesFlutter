## [2.0.3]

- [Fixed] Fix Loading Issue in IoS and Update packages dependencies to  the latest version 
- 
## [2.0.2]

- [Fixed] Update packages dependencies to  the latest version.
- 
## [2.0.1]

- [Fixed] Prevented highchart link to open within webview and redirecting to broswer.

## [1.2.0] - 2021-06-05

- Update to Null safety

## [1.0.1] - 2021-01-16

- update in README.md

## [1.0.0] - 2021-01-16

- stable release of high_chart

## [0.0.1] - 2020-01-15

- Initial release
