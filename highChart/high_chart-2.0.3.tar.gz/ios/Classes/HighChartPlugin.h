#import <Flutter/Flutter.h>

@interface HighChartPlugin : NSObject<FlutterPlugin>
@end
