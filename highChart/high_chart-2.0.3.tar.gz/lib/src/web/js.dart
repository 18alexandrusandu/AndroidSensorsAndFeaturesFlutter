library highcharts_js_web;

import 'package:js/js.dart';

///
/// A JavaScript module for eval function.
///
@JS('eval')
external void eval(String code);
