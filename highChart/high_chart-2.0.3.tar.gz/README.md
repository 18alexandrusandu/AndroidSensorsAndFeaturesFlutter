<p align="center">
<img src="https://i.ibb.co/GnKh9tp/kisspng-highsoft-highcharts-data-visualization-technology-crisp-5b0bc0d5cc2c53-729988461527496917836.jpg" />
</p>


[![pub package](https://img.shields.io/pub/v/high_chart.svg?label=high_chart&color=blue)](https://pub.dev/packages/high_chart)
[![popularity](https://badges.bar/high_chart/popularity)](https://pub.dev/packages/high_chart/score)
[![pub points](https://badges.bar/high_chart/pub%20points)](https://pub.dev/packages/high_chart/score)
![building](https://github.com/senthilnasa/high_chart/workflows/build/badge.svg)


# High Charts Package for Flutter
A Flutter package to use [High Charts](https://www.highcharts.com/)

## Usage
To use this plugin, please visit the [Usage documentation](https://github.com/senthilnasa/high_chart/wiki)
